package com.learning.entity;

public class Transfer {
	Long tranfer_id;
	Long from_acct;
	String reasonForTransfer;
	Long to_acct;
	Boolean approved;

}
